Çalıştırma:

    Eğer PHP binary'si bilgisayarınızda yüklüyse:
    - `php -S localhost:8080` çalıştırın
    - İnternet tarayıcınızda `http://localhost:8080` adresine gidin.

    Eğer yüklü değilse:
    - WAMP veya XAMPP klasörüne atabilirsiniz.

    Gerekli eklentiler:
    - GP

Sayfalar:

- `/`: Basit bir quiz oyunu.
- `/image`: `imgs` klasöründeki olan resimleri ASCII karakterlerini kullanarak web sayfasına yazdırır.
